<?php
/*
 * @component AlphaContent
 * @copyright Copyright (C) 2005 - 2011 Bernard Gilly. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// num version
if(!defined("_ALPHACONTENT_NUM_VERSION")) {
   DEFINE( "_ALPHACONTENT_NUM_VERSION", "4.0.18" );
}
?>